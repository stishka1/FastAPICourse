from fastapi import APIRouter

router = APIRouter(prefix="/rooms", tags=['Комнаты'])

@router.get("")
async def get_rooms():
    ...

@router.get("{/room_id}")
async def get_room_info():
    pass

@router.post("", summary="Добавление новой комнаты")
async def add_new_room():
    pass

